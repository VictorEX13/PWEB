var app = require('./app/config/server');

var rotaIndex = require('./app/routes/index');
rotaIndex(app);

app.listen(3000, function(){
  console.log("servidor iniciado");
});