var app = require('./config/server');

var rotaHome = require('./App/routes/home');
rotaHome(app);


app.listen(3000, function(){
  console.log("servidor iniciado");
  });